# 📰 Python News Scraper

A simple Python script to scrape top news headlines from websites using `requests` and `BeautifulSoup`.

## 📌 Features
- Fetch headlines from a news website
- Save headlines to a `.txt` file
- Easy to customize for different websites

## ⚙️ Installation
```bash
git clone https://github.com/your-username/python-news-scraper.git
cd python-news-scraper
pip install -r requirements.txt
```

## 🚀 Usage
```bash
python news_scraper.py
```

## 📂 Output
The script will create a file called `headlines.txt` containing scraped headlines.

## 🛠️ Tools Used
- Python
- Requests
- BeautifulSoup

## 🎯 Outcome
Automates data collection from a public website.
