import requests
from bs4 import BeautifulSoup

def scrape_headlines(url, tag="h2"):
    try:
        # Fetch HTML content
        response = requests.get(url)
        response.raise_for_status()
        
        # Parse with BeautifulSoup
        soup = BeautifulSoup(response.text, "html.parser")
        
        # Extract headlines
        headlines = [headline.get_text(strip=True) for headline in soup.find_all(tag)]
        
        return headlines
    
    except Exception as e:
        print("Error occurred:", e)
        return []

def save_to_file(headlines, filename="headlines.txt"):
    with open(filename, "w", encoding="utf-8") as f:
        for idx, headline in enumerate(headlines, start=1):
            f.write(f"{idx}. {headline}\n")
    print(f"✅ Headlines saved to {filename}")

if __name__ == "__main__":
    # Example: scraping from BBC News
    url = "https://www.bbc.com/news"
    
    print(f"Scraping headlines from: {url}")
    headlines = scrape_headlines(url, tag="h3")  # BBC often uses h3 tags
    
    if headlines:
        save_to_file(headlines)
        print("Top 10 Headlines:")
        for h in headlines[:10]:
            print("-", h)
    else:
        print("No headlines found.")
